# FlashBoard v1.1.0

**Определение устройств и прошивка: телефоны, часы, наушники, платы ESP32 / STM32 / Arduino.**

Один файл — `FlashBoard.exe` (Windows 10/11, Python не нужен). Внутри программа,
иконка и библиотека прошивок. При первом запуске приложение само скачивает
инструменты для прошивки и распаковывает встроенные образы.

## Как пользоваться

1. Скачайте `FlashBoard.exe` и запустите его.
2. Дождитесь, пока в журнале появится «Инструменты: …» — при первом запуске
   скачивается около 150 МБ (esptool, adb, fastboot, dfu-util, avrdude,
   openocd, picotool, dfu-programmer, nrfjprog). Приложением можно
   пользоваться, пока идёт загрузка.
3. Подключите устройство по USB — оно появится в списке слева.
4. Выберите прошивку (или скачайте её кнопкой **⬇**) и нажмите **ПРОШИТЬ**.

## Что поддерживается

| Устройство | Метод |
|---|---|
| ESP32 / S2 / S3 / C3 / C6 / ESP8266 | `esptool` |
| Raspberry Pi Pico | UF2 / `picotool` |
| Телефон Android | `adb sideload`, `fastboot` |
| Часы Wear OS | `adb sideload`, `fastboot` |
| Galaxy Watch | Galaxy Watch Manager |
| Наушники TWS (Nordic nRF52) | `dfu-util`, `nrfjprog`, `openocd` |
| STM32 | `dfu-util`, `openocd`, STM32CubeProgrammer |
| Arduino Uno/Mega | `avrdude` |
| Arduino Zero/MKR (SAMD) | `dfu-programmer` |
| Любое другое | своя команда |

## Важно

* Fastboot требует **разблокированного загрузчика**.
* Режим EDL 9008 (Qualcomm) требует авторизованного firehose-программатора.
* iOS-устройства определяются, но прошить их с ПК нельзя.
* Прошивка под конкретную модель подбирается автоматически по типу чипа.

## Проверка файла

```
SHA256SUMS.txt
```

Сверьте сумму командой:

```bat
certutil -hashfile FlashBoard.exe SHA256
```

## Лицензия

MIT — см. [LICENSE](LICENSE).
